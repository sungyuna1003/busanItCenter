package tib;

public class TravelBean_info {

	private int UC_SEQ;
	private String MAIN_TITLE;
	private String GUGUN_NM;
	private int LAT;
	private int LNG;
	private int GRIDX;
	private int GRIDY;
	private String PLACE;
	private String TITLE;
	private String SUBTITLE;
	private String ADDR1;
	private String CNTCT_TEL;
	private String HOMEPAGE_URL;
	private String TRFC_INFO;
	private String USAGE_DAY;
	private String HLDY_INFO;
	private String USAGE_DAY_WEEK_AND_TIME;
	private String USAGE_AMOUNT;
	private String MIDDLE_SIZE_RM1;
	private String MAIN_IMG_THUMB;
	private String ITEMCNTNTS;


	public int getUC_SEQ() {
		return UC_SEQ;
	}                 
	public void setUC_SEQ(int UC_SEQ) {
		this.UC_SEQ = UC_SEQ;
	}
	public String getMAIN_TITLE() {
		return MAIN_TITLE;
	}
	public void setMAIN_TITLEe(String MAIN_TITLE) {
		this.MAIN_TITLE = MAIN_TITLE;
	}
	public String getGUGUN_NM() {
		return GUGUN_NM;
	}
	public void setGUGUN_NM(String GUGUN_NM) {
		this.GUGUN_NM = GUGUN_NM;
	}
	public int getLAT() {
		return LAT;
	}             
	public void setLAT(int LAT) {
		this.LAT = LAT;
	}
	public int  getLNG() {
		return LNG;
	}
	public void setLNG(int LNG) {
		this.LNG = LNG;
	}                 
	public int getGRIDX() {
		return GRIDX;
	}            
	public void setGRIDX(int GRIDX) {
		this.GRIDX = GRIDX;
	}
	public int getGRIDY() {
		return GRIDY;
	}                 
	public void setgetGRIDY(int GRIDY) {
		this.GRIDY= GRIDY;
	}
	public String getPLACE() {
		return PLACE;
	}
	public void setPLACE(String PLACE) {
		this.PLACE = PLACE;
	}
	public String getTITLE() {
		return TITLE;
	}
	public void setTITLE(String TITLE) {
		this.TITLE = TITLE;
	}
	public String getSUBTITLE() {
		return SUBTITLE;
	}
	public void setSUBTITLE(String SUBTITLE) {
		this.SUBTITLE = SUBTITLE;
	}
	public String getADDR1() {
		return ADDR1;
	}
	public void setADDR1(String ADDR1) {
		this.ADDR1 = ADDR1;
		}
	public String getCNTCT_TEL() {
		return CNTCT_TEL;
	}
	public void setCNTCT_TEL(String CNTCT_TEL) {
		this.CNTCT_TEL = CNTCT_TEL;
		}
	public String getTRFC_INFO() {
		return TRFC_INFO;
	}
	public void setTRFC_INFO(String TRFC_INFO) {
		this.TRFC_INFO = TRFC_INFO;
	}
	public String getUSAGE_DAY() {
		return USAGE_DAY;
	}
	public void setUSAGE_DAY(String USAGE_DAY) {
		this.USAGE_DAY = USAGE_DAY;
		}
	public String getHLDY_INFO() {
		return HLDY_INFO;
	}
	public void setHLDY_INFO(String HLDY_INFO) {
		this.HLDY_INFO = HLDY_INFO;
		}
	public String getUSAGE_DAY_WEEK_AND_TIME() {
		return USAGE_DAY_WEEK_AND_TIME;
	}
	public void setUSAGE_DAY_WEEK_AND_TIME(String USAGE_DAY_WEEK_AND_TIME) {
		this.USAGE_DAY_WEEK_AND_TIME = USAGE_DAY_WEEK_AND_TIME;
	}
	public String getUSAGE_AMOUNT() {
		return USAGE_AMOUNT;
	}
	public void setUSAGE_AMOUNT(String USAGE_AMOUNT) {
		this.USAGE_AMOUNT = USAGE_AMOUNT;
	}
		public String getMIDDLE_SIZE_RM1() {
			return MIDDLE_SIZE_RM1;
		}
		public void setMIDDLE_SIZE_RM1(String MIDDLE_SIZE_RM1) {
			this.MIDDLE_SIZE_RM1 = MIDDLE_SIZE_RM1;
		}
			public String getMAIN_IMG_THUMB() {
				return MAIN_IMG_THUMB;
			}
			public void setMAIN_IMG_THUMB(String MAIN_IMG_THUMB) {
				this.MAIN_IMG_THUMB = MAIN_IMG_THUMB;
			}
			public String getITEMCNTNTS() {
				return ITEMCNTNTS;
			}
			public void setITEMCNTNTS(String ITEMCNTNTS) {
				this.ITEMCNTNTS = ITEMCNTNTS;
}
}